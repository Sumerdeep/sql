
-- ============================================================================
-- SECTION 0: DATABASE & TABLE SETUP
-- ============================================================================
CREATE DATABASE IF NOT EXISTS fashion_brand;
USE fashion_brand;

DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    customer_id            INT,
    age                    INT,
    gender                 VARCHAR(10),
    item_purchased         VARCHAR(50),
    category               VARCHAR(20),
    purchase_amount        FLOAT,
    location               VARCHAR(50),
    size                   VARCHAR(5),
    color                  VARCHAR(20),
    season                 VARCHAR(10),
    review_rating          FLOAT,
    subscription_status    VARCHAR(5),
    shipping_type          VARCHAR(20),
    discount_applied       VARCHAR(5),
    previous_purchases     INT,
    payment_method         VARCHAR(20),
    frequency_of_purchases VARCHAR(20),
    no_review_flag         INT,
    is_discounted          INT,
    is_subscriber          INT,
    frequency_score        INT,
    value_score            FLOAT,
    value_tier             VARCHAR(10),
    purchase_history_tier  VARCHAR(10),
    promo_dependency_score INT,
    satisfaction_flag      VARCHAR(15),
    age_band               VARCHAR(10),
    loyal_a                INT,
    loyal_b                INT,
    loyalty_final          INT
);


SELECT COUNT(*) AS total_rows FROM customers;   -
SELECT * FROM customers LIMIT 5;


-- ============================================================================
-- QUERY 1 — LOYAL vs DISCOUNT-DEPENDENT  (Key Question 1)
-- Splits all customers into four mutually exclusive, traceable segments.
-- Headline: Full-Price Loyalists and Discount-Dependent Veterans carry almost
-- identical value (~2,510) and purchase history (~42), but one pays full price
-- and the other is discounted 100% of the time — the brand's core problem.
-- ============================================================================
SELECT
    CASE
        WHEN loyalty_final = 1
            THEN '1. Full-Price Loyalist'          -- top-third buyer, never discounted
        WHEN is_discounted = 0 AND loyalty_final = 0
            THEN '2. Organic Occasional'           -- pays full price, not a heavy repeat buyer
        WHEN is_discounted = 1 AND purchase_history_tier = 'High'
            THEN '3. Discount-Dependent Veteran'   -- buys a lot, but ALWAYS on discount
        ELSE '4. Discount Hunter'                  -- low history + discount = bargain seeker
    END AS customer_segment,

    COUNT(*)                                        AS total_customers,
    ROUND(AVG(purchase_amount), 2)                  AS avg_spend,
    ROUND(AVG(previous_purchases), 1)               AS avg_purchase_history,
    ROUND(AVG(value_score), 0)                      AS avg_value_score,
    ROUND(100.0 * SUM(is_discounted) / COUNT(*), 1) AS pct_discounted,
    ROUND(AVG(review_rating), 2)                    AS avg_satisfaction
FROM customers
GROUP BY customer_segment
ORDER BY customer_segment;


-- ============================================================================
-- QUERY 2 — WHAT BEHAVIOR PREDICTS VALUE  (Key Question 2)
-- A 3x3 grid crossing value_tier with purchase_history_tier. Shows that value
-- tracks purchase history, and that discount usage stays flat (~43%) across
-- every cell — i.e. discounts are not what create value.
-- ============================================================================
SELECT
    value_tier,
    purchase_history_tier,
    COUNT(*)                                        AS total_customers,
    ROUND(AVG(purchase_amount), 2)                  AS avg_spend,
    ROUND(AVG(frequency_score), 2)                  AS avg_frequency,
    ROUND(AVG(review_rating), 2)                    AS avg_rating,
    ROUND(100.0 * SUM(is_discounted) / COUNT(*), 1) AS discount_pct,
    ROUND(100.0 * SUM(CASE WHEN satisfaction_flag = 'Satisfied'
                           THEN 1 ELSE 0 END) / COUNT(*), 1) AS satisfaction_pct
FROM customers
GROUP BY value_tier, purchase_history_tier
ORDER BY avg_spend DESC;


-- ============================================================================
-- QUERY 3 — GEOGRAPHIC OPPORTUNITY  (Key Question 3)
-- Flags states with genuine organic pull: above-average spend AND below-average
-- discount reliance. Thresholds are the dataset's own averages (the benchmarks
-- CTE), not hardcoded guesses, so the classification adapts to the data.
-- ============================================================================
WITH benchmarks AS (
    SELECT
        AVG(purchase_amount)                       AS mean_spend,
        100.0 * SUM(is_discounted) / COUNT(*)      AS mean_discount_pct
    FROM customers
)
SELECT
    location,
    COUNT(*)                                        AS total_customers,
    ROUND(AVG(purchase_amount), 2)                  AS avg_spend,
    ROUND(100.0 * SUM(is_discounted) / COUNT(*), 1) AS discount_pct,
    ROUND(100.0 * SUM(CASE WHEN satisfaction_flag = 'Satisfied'
                           THEN 1 ELSE 0 END) / COUNT(*), 1) AS satisfaction_pct,
    CASE
        WHEN AVG(purchase_amount) > (SELECT mean_spend FROM benchmarks)
         AND 100.0 * SUM(is_discounted) / COUNT(*) < (SELECT mean_discount_pct FROM benchmarks)
            THEN 'High Opportunity (organic pull)'
        WHEN AVG(purchase_amount) > (SELECT mean_spend FROM benchmarks)
            THEN 'High Spend but Discount-Driven'
        WHEN 100.0 * SUM(is_discounted) / COUNT(*) < (SELECT mean_discount_pct FROM benchmarks)
            THEN 'Organic but Low Spend'
        ELSE 'Low Priority'
    END AS geo_segment
FROM customers
GROUP BY location
ORDER BY avg_spend DESC, discount_pct ASC;


-- ============================================================================
-- QUERY 4 — PROMO RESTRUCTURING / DISCOUNT LIFT  (Key Question 4)
-- For each category: average spend of discounted buyers MINUS full-price buyers.
-- A negative "discount_lift" means discounts coincide with LOWER spend — pure
-- margin leakage. Outerwear, Accessories, Clothing are negative; only Footwear
-- shows a small positive lift. Sunset discounts where lift <= 0 first.
-- ============================================================================
WITH category_split AS (
    SELECT
        category,
        AVG(CASE WHEN is_discounted = 0 THEN purchase_amount END) AS spend_full_price,
        AVG(CASE WHEN is_discounted = 1 THEN purchase_amount END) AS spend_discounted,
        COUNT(*)                                                 AS total_customers,
        ROUND(100.0 * SUM(is_discounted) / COUNT(*), 1)          AS discount_pct
    FROM customers
    GROUP BY category
)
SELECT
    category,
    ROUND(spend_full_price, 2)                     AS avg_spend_full_price,
    ROUND(spend_discounted, 2)                     AS avg_spend_discounted,
    ROUND(spend_discounted - spend_full_price, 2)  AS discount_lift,   -- negative = margin leak
    discount_pct,
    total_customers
FROM category_split
ORDER BY discount_lift ASC;


-- ============================================================================
-- QUERY 5 — IDEAL CUSTOMER PROFILE  (Key Question 5)
-- Filters to the genuinely loyal segment (loyalty_final = 1) and describes the
-- most common profiles within it: age band, gender, category, payment method,
-- plus spend / history / frequency / rating. The top rows are the ICP marketing
-- should target. (Remove GROUP BY for a single-line summary of the loyal base.)
-- ============================================================================
SELECT
    age_band,
    gender,
    category,
    payment_method,
    COUNT(*)                            AS loyal_customers,
    ROUND(AVG(age), 1)                  AS avg_age,
    ROUND(AVG(purchase_amount), 2)      AS avg_spend,
    ROUND(AVG(previous_purchases), 1)   AS avg_purchase_history,
    ROUND(AVG(frequency_score), 2)      AS avg_frequency,
    ROUND(AVG(review_rating), 2)        AS avg_rating
FROM customers
WHERE loyalty_final = 1
GROUP BY age_band, gender, category, payment_method
ORDER BY loyal_customers DESC
LIMIT 10;


